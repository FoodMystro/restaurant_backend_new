

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="FoodMystro - Online ordering platform">
	<meta name="author" content="FoodMystro">
	<title>Back Office | Papa Nadox Kitchen | Powered by FoodMystro</title>
	
	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.svg" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(asset('')); ?>assets/img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(asset('')); ?>assets/img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(asset('')); ?>assets/img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(asset('')); ?>assets/img/apple-touch-icon-144x144-precomposed.png">

    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('')); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>assets/css/style.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="<?php echo e(asset('')); ?>assets/css/order-sign_up.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(asset('')); ?>assets/css/custom.css" rel="stylesheet">
    
</head>

<body id="register_bg">
	
	<div id="register">
		<aside>
			<figure>
				<a href="index.html"><img src="<?php echo e(asset('')); ?>assets/img/logo_sticky.svg" width="140" height="35" alt=""></a>
			</figure>
			<div class="access_social">
				<h4 class="text-center">Log in to your Back Office</h4><br>
			</div>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
				<div class="form-group">
                <input id="email" type="email" placeholder="Email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					<i class="icon_mail_alt"></i>
				</div>
				<div class="form-group">
                <input id="password" type="password"  placeholder="Password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					<i class="icon_lock_alt"></i>
				</div>
				<div class="clearfix add_bottom_15">
					<div class="checkboxes float-start">	
                        <label class="container_check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <?php echo e(__('Remember Me')); ?>

                                <input type="checkbox">
                                <span class="checkmark"></span>
						</label>
					</div>
					<!-- <div class="float-end"><a id="forgot" href="#0">Forgot Password?</a></div> -->
				</div>
                <button href="https://backend.foodmystro.com" target="_blank" class="btn_1 gradient full-width">

                                    <?php echo e(__('Login Now!')); ?>

                 </button>
                                <!-- <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?> -->
				<!-- <div class="text-center mt-2"><small>Don't have an acccount? <strong><a href="register.html">Sign Up</a></strong></small></div> -->
			</form>
			<div class="copy">© Papa Nadox Kitchen | Powered by <a href="https://foodmystro.com" target="_blank"><b>FoodMystro</b></a></div>
		</aside>
	</div>
	<!-- /login -->
	
	<!-- COMMON SCRIPTS -->  
    <script src="<?php echo e(asset('')); ?>assets/js/common_scripts.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/js/common_func.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/assets/validate.js"></script>

  
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softsuitetech/public_html/DEMO/restuarant/resources/views/auth/login.blade.php ENDPATH**/ ?>