

<?php $__env->startSection('content'); ?>

<body class="fixed-nav sticky-footer" id="page-top">
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Admin Backend</li>
      </ol>

        <div class="box_general padding_bottom">
            <div class="header_box version_2">
                <h2><i class="fa fa-file"></i>Add New Admin User</h2>
            </div>
            <!-- <div class="row">
                <div class="col-md-6">
                    <div class="form-group radio_c_group no_label">
                        <label>Available For:</label><br>
                        <label class="container_check">Delivery
                            <input type="checkbox" value="checkbox" name="delivery">
                            <span class="checkmark"></span>
                        </label>
                        <label class="container_check">Collection
                            <input type="checkbox" value="checkbox" name="collection">
                            <span class="checkmark"></span>
                        </label>
                        <label class="container_check">Table Service
                            <input type="checkbox" value="checkbox" name="table-service">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div> -->

                <div class="col-md-12">
                    <p><a href="<?php echo e(route('add_new_admin')); ?>" class="btn_1 medium">Add Admin User</a> </p>
                </div>
                        
            </div>
        </div>
		<!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> User Management</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Permissions</th>
                    <th>Action</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Permissions</th>
                    <th>Action</th>
                </tr>
              </tfoot>
              <tbody>
                <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->id); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->last_name); ?></td>
                    <td><?php echo e($data->email); ?></td>

                    <td>
                     <?php if($data->status == 0): ?>
                      <i class="cancel">Not Active</i>
                      <?php endif; ?>
                      <?php if($data->status == 1): ?>
                      <i class="approved">Active</i>
                      <?php endif; ?>
                    </td>

                    <td><?php echo e($data->permission); ?></td>
                    <td><a href="<?php echo e(route('edit_admin',[$data->id])); ?>"><strong>Edit</strong></a> | <a href="<?php echo e(route('delete_admin',[$data->id])); ?>"><strong>Delete</strong></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <tr>
                    <td>13</td>
                    <td>Dan </td>
                    <td>Alfredo</td>
                    <td>Dan.Alfredo@email.com</td>
                    <td><i class="cancel">Not Active</i></td>
                    <td>Store Owner</td>
                    <td><a href="add-new-admin.html"><strong>Edit</strong></a> | <a href="#0"><strong>Delete</strong></a></td>

                </tr>
                 <tr>
                    <td>14</td>
                    <td>Valeria</td>
                    <td>Felice</td>
                    <td>Taxo.Mex@email.com</td>
                    <td><i class="approved">Active</i></td>
                    <td>Store Manager</td>
                    <td><a href="add-new-admin.html"><strong>Edit</strong></a> | <a href="#0"><strong>Delete</strong></a></td>
                </tr>
                <tr>
                    <td>15</td>
                    <td>Smtih</td>
                    <td>Mex</td>
                    <td>Smtih.Mex@email.com</td>
                    <td><i class="approved">Active</i></td>
                    <td>Basic User</td>
                    <td><a href="add-new-admin.html"><strong>Edit</strong></a> | <a href="#0"><strong>Delete</strong></a></td>
                </tr> -->
            </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
	  <!-- /tables-->
        <!-- /row-->
	  </div>
	  <!-- /container-fluid-->
   	</div>
    <!-- /container-wrapper-->

    

   
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
  
    

</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH T:\xampp\htdocs\restaurant\resources\views/backend/layout/admin_backend.blade.php ENDPATH**/ ?>