
<?php $__env->startSection('content'); ?>

<main class="bg_gray">
		
		<div class="container margin_60_20" style="margin-top:60px;">
			<form action="<?php echo e(route('checkout')); ?>" method="POST" class="needs-validation" >
				
				<?php echo csrf_field(); ?>
				<div class="row justify-content-center">
					<div class="col-xl-6 col-lg-8">
						<div class="box_order_form">
							<div class="head">
								<div class="title">
									<h3>Personal Details</h3>
								</div>
							</div>
							<!-- /head -->
							<div class="main">
								<div class="form-group">
									<label>First and Last Name</label>
									<input class="form-control" type="text" name="name" value="" placeholder="First and Last Name" required>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Email Address</label>
											<input class="form-control" type="email" name="email" value=""  placeholder="Email Address" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Phone</label>
											<input class="form-control" type="integer" name="phone" value=""  placeholder="Phone" required>
										</div>
									</div>
								</div>
								<div class="form-group">
									<label>Full Address</label>
									<input class="form-control" type="text" name="address" value=""  placeholder="Full Address" required>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>City</label>
											<input class="form-control" type="text" name="city" value=""  placeholder="City">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Postal Code</label>
											<input class="form-control" type="text" name="postcode" value=""  placeholder="0123">
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /box_order_form -->
						
						<!-- /box_order_form -->
					</div>
					<!-- /col -->
					<div class="col-xl-4 col-lg-4" id="sidebar_fixed">
						<div class="box_order">
							<div class="head">
								<h3>Order Summary</h3>
								<div>Pizzeria da Alfredo</div>
							</div>
							<!-- /head -->
							<div class="main">
								
								<?php $total = 0 ?>
							<?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $total += $details['price'] * $details['quantity'] ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<ul>
									
									
									<li>Type<span><?php echo e($details['type']); ?></span></li>
								</ul>
								<hr>
								<ul class="clearfix">
									<?php if(session('cart')): ?>
											<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
											 <?php if($payment->default_currency == 1): ?>
										<li><a href="<?php echo e(route('remove.cart',$id)); ?>" class="remove_cart" data-id="<?php echo e($id); ?>" data-token="<?php echo e(csrf_token()); ?>" ><?php echo e($details['quantity']); ?>x <?php echo e($details['name']); ?></a><span>£ <?php echo e($details['price']); ?></span></li>
											<?php endif; ?>
											
											 <?php if($payment->default_currency == 2): ?>
										<li><a href="<?php echo e(route('remove.cart',$id)); ?>" class="remove_cart" data-id="<?php echo e($id); ?>" data-token="<?php echo e(csrf_token()); ?>" ><?php echo e($details['quantity']); ?>x <?php echo e($details['name']); ?></a><span>$ <?php echo e($details['price']); ?></span></li>
											<?php endif; ?>
										
										
										 <?php if($payment->default_currency == 3): ?>
										<li><a href="<?php echo e(route('remove.cart',$id)); ?>" class="remove_cart" data-id="<?php echo e($id); ?>" data-token="<?php echo e(csrf_token()); ?>" ><?php echo e($details['quantity']); ?>x <?php echo e($details['name']); ?></a><span>€ <?php echo e($details['price']); ?></span></li>
											<?php endif; ?>
											
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
								</ul>
								
								<ul class="clearfix">
								    
								    <?php if($payment->default_currency == 1): ?>
									<li>Subtotal<span>£ <?php echo e($total); ?></span></li>
									<?php endif; ?>
									
									 <?php if($payment->default_currency == 2): ?>
									<li>Subtotal<span>$ <?php echo e($total); ?></span></li>
									<?php endif; ?>
									
									 <?php if($payment->default_currency == 3): ?>
									<li>Subtotal<span>€ <?php echo e($total); ?></span></li>
									 <?php endif; ?>
									
									 <?php if($payment->default_currency == 1): ?>
									<li>Delivery fee<span>£ 0</span></li>
									 <?php endif; ?>
									
									 <?php if($payment->default_currency == 2): ?>
									<li>Delivery fee<span>$ 0</span></li>
									 <?php endif; ?>
									 
									  <?php if($payment->default_currency == 3): ?>
									<li>Delivery fee<span>€ 0</span></li>
									 <?php endif; ?>
									
									<?php if($payment->default_currency == 1): ?>
									<li class="total">Total<span>£ <?php echo e($total); ?></span></li>
									<?php endif; ?>
									
									<?php if($payment->default_currency == 2): ?>
									<li class="total">Total<span>$ <?php echo e($total); ?></span></li>
									<?php endif; ?>
									
									
									<?php if($payment->default_currency == 3): ?>
									<li class="total">Total<span>€ <?php echo e($total); ?></span></li>
									<?php endif; ?>
								</ul>
								
								<?php $grand_total = 0 ?>
								<?php if(session('cart')): ?>
									<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $grand_total += $details['price'] * $details['quantity'] ?>
										<input type="hidden" name="item_id[]" value="<?php echo e($details['id']); ?>">
										<input type="hidden" name="type" value="<?php echo e($details['type']); ?>">
										<input type="hidden" name="price[]" value="<?php echo e($details['price']); ?>">
										<input type="hidden" name="qty[]" value="<?php echo e($details['quantity']); ?>">
										<input type="hidden" name="sub_total[]" value="<?php echo e($details['price'] * $details['quantity']); ?>">
										<input type="hidden" name="grand_total" value="<?php echo e($grand_total); ?>">
										<input type="hidden" name="sub_total" value="<?php echo e($grand_total); ?>">
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<button class="btn_1 gradient full-width mb_5">Order Now</button>
								<div class="text-center"><small>Or Call Us at <strong>0432 48432854</strong></small></div>
							</div>
						</div>
						<!-- /box_booking -->
					</div>

				</div>
			</form>
		    <!-- /row -->
		</div>
		<!-- /container -->
		
	</main>
	<!-- /main -->

	

	<div id="toTop"></div><!-- Back to top button -->
	
	<!-- Sign In Modal -->
	<div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
		<div class="modal_header">
			<h3>Sign In</h3>
		</div>
		<form>
			<div class="sign-in-wrapper">
				<a href="#0" class="social_bt facebook">Login with Facebook</a>
				<a href="#0" class="social_bt google">Login with Google</a>
				<div class="divider"><span>Or</span></div>
				<div class="form-group">
					<label>Email</label>
					<input type="email" class="form-control" name="email" id="email">
					<i class="icon_mail_alt"></i>
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control" name="password" id="password" value="">
					<i class="icon_lock_alt"></i>
				</div>
				<div class="clearfix add_bottom_15">
					<div class="checkboxes float-start">
						<label class="container_check">Remember me
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>
					</div>
					<div class="float-end"><a id="forgot" href="javascript:void(0);">Forgot Password?</a></div>
				</div>
				<div class="text-center">
					<input type="submit" value="Log In" class="btn_1 full-width mb_5">
					Don’t have an account? <a href="register.html">Sign up</a>
				</div>
				<div id="forgot_pw">
					<div class="form-group">
						<label>Please confirm login email below</label>
						<input type="email" class="form-control" name="email_forgot" id="email_forgot">
						<i class="icon_mail_alt"></i>
					</div>
					<p>You will receive an email containing a link allowing you to reset your password to a new preferred one.</p>
					<div class="text-center"><input type="submit" value="Reset Password" class="btn_1"></div>
				</div>
			</div>
		</form>
		<!--form -->
	</div>
	<!-- /Sign In Modal -->
	
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softsuitetech/public_html/DEMO/Restaurant_Backend/resources/views/frontend/layout/order.blade.php ENDPATH**/ ?>