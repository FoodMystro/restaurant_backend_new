

<?php $__env->startSection('content'); ?>

    
<div class="content-wrapper">
    <div class="container-fluid">                        
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="menu-items.html">CMS Home Card</a>
            </li>
            <li class="breadcrumb-item active">Add Cards</li>
        </ol>
                                                                    
        <div class="box_general padding_bottom">
            <div class="header_box version_2">
                <h2><i class="fa fa-list"></i>Add New Cards</h2>
            </div>
                          
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="form-group">
                            <div>
                                <label>Icon </label>
                                <input type="text" name="sec2_card2_icon2" class="form-control" value="">
                            </div>
                            <div><br>
                                <label>Heading </label>
                                <input type="text" name="sec2_card2_heading2" class="form-control" value="">
                            </div><br>
                            <div>
                                <label>Paragraph </label>
                                <input type="text" name="sec2_card2_paragraph2" class="form-control" value="">
                            </div>
                        </div>
                    </div>
                </div> 
                </div>
                <div class="col-md-3"></div>
            </div>
          
            
            <div class="wrapper_indent">
    </div>
</div>

          
           

          
</body>

</html>

<?php $__env->stopSection(); ?>


                
        
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodmystro\resources\views/backend/layout/website/help_card.blade.php ENDPATH**/ ?>