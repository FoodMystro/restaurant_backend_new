<footer class="sticky-footer">
        <div class="container">
            <div class="text-center">
                <small>Copyright © Business Name | Powered by FoodMystro</small>
            </div>
        </div>
    </footer><?php /**PATH /home/softsuitetech/public_html/DEMO/Restaurant_Backend/resources/views/backend/layout/partials/footer.blade.php ENDPATH**/ ?>