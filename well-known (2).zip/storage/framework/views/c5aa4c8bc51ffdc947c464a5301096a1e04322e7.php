
 

 
 <?php $__env->startSection('content'); ?>
 <body class="fixed-nav sticky-footer" id="page-top">
     <div class="content-wrapper">
         <div class="container-fluid">
             <!-- Breadcrumbs-->
             
             <ol class="breadcrumb">
                 <li class="breadcrumb-item">
                     <a href="menu-items.html">Menu Items</a>
                 </li>
                 <li class="breadcrumb-item active">Edit Menu Item</li>
             </ol>
             <!-- /box_general-->
             <div class="box_general padding_bottom">
                 <div class="header_box version_2">
                     <h2><i class="fa fa-list"></i>Edit Menu item</h2>
                 </div>
                 <div class="wrapper_indent">
                 <form action="<?php echo e(route('update_menu',['id'=>$display->id])); ?>" method="post">
                     <?php echo csrf_field(); ?>
                     <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($display->name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                             <div class="form-group">
                                 <label>Choose Category</label>
                                 <div class="styled-select">
                                     <select name="category">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option><?php echo e($categories->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                             </div>
                         </div>
                    </div> 
                       
                  
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Price</label>
                                <input type="text" name="price" class="form-control" value="<?php echo e($display->price); ?>">
                            </div>
                        </div> 
                         <div class="col-md-6">
                             <div class="form-group">
                                 <label>Availability</label>
                                 <div class="styled-select">
                                     <select name="availability">
                                         <option value="1">Available to Order</option>
                                         <option value="0">Out of Stock</option>
                                     </select>
                                 </div>
                             </div>
                         </div>
                     </div>
                
                     <!-- /row-->
                     
                     <div class="strip_menu_items">
                         <div class="row">
                             
                             <!-- <div class="col-xl-9">
                                 <div class="row">
                                     <div class="col-md-6">
                                         <div class="form-group">
                                             <label>Name</label>
                                             <input type="text" name="name" class="form-control">
                                         </div>
                                     </div>
                                     <div class="col-md-6">
                                         <div class="form-group">
                                             <label>Price</label>
                                             <input type="text" class="form-control" name="price1">
                                         </div>
                                     </div>
                                 </div>  -->
                             </div>
                             <!-- End row -->
                     </div>
                     <!-- /box_general-->
                 </div>
                 <!-- /.container-fluid-->
                 <p><button type="submit" class="btn btn-success">Update</button></p>
             </div>
             <!-- /.container-wrapper-->
        </form>
      
        
         <!-- Scroll to Top Button-->
         <a class="scroll-to-top rounded" href="#page-top">  <i class="fa fa-angle-up"></i> </a>
               
 </body>
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodmystro\resources\views/backend/layout/edit_menu.blade.php ENDPATH**/ ?>