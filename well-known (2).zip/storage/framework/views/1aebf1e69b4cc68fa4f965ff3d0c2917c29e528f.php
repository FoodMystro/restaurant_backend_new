
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<body class="fixed-nav sticky-footer" id="page-top">
    <!-- Navigation-->
  
    <!-- /Navigation-->
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
        <form action="<?php echo e(route('add_admin')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Add admin user</li>
            </ol>
            <!-- /box_general-->
            <div class="box_general padding_bottom">
                <div class="header_box version_2">
                    <h2><i class="fa fa-list"></i>Add New Admin</h2>
                </div>
                <div class="wrapper_indent">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group radio_c_group no_label">
                                <label>Available For:</label><br>
                                <label class="container_check">Delivery
                                    <input type="checkbox" value="1" name="delivery" <?php if($data->delivery == 1): ?> checked <?php endif; ?>>
                                    <span class="checkmark"></span>
                                </label>
                                <label class="container_check">Collection
                                    <input type="checkbox" value="1" name="collection" <?php if($data->collection == 1): ?> checked <?php endif; ?>>
                                    <span class="checkmark"></span>
                                </label>
                                <label class="container_check">Table Service
                                    <input type="checkbox" value="1" name="table_service" <?php if($data->table_service == 1): ?> checked <?php endif; ?>>
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" name="last_name" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Phone No.</label>
                                <input type="tel" name="phone_no" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Status</label>
                                <div class="styled-select">
                                    <select name="status">
                                        <option value="1">Active</option>
                                        <option value="0">Not Active</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Permissions</label>
                                <div class="styled-select">
                                    <select name="permission">
                                        <option>Super Admin</option>
                                        <option>Store Owner</option>
                                        <option>Store Manager</option>
                                        <option>Basic User</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Enter New Password</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                        </div>
                    </div>
           
                    <!-- /row-->
                    <!-- /box_general-->
                </div>
                <!-- /.container-fluid-->
                <div class="row">
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-success">ADD</button>
                    </div>
                    <div class="col-md-4"></div>
                    <div class="col-md-4"></div>
                </div>
            </div>
            <!-- /.container-wrapper-->
        </form>


            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fa fa-angle-up"></i>
            </a>
             
        
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/softsuitetech/public_html/DEMO/restuarant/resources/views/backend/layout/add_new_admin.blade.php ENDPATH**/ ?>