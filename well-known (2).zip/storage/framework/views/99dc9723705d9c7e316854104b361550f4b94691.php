
 
 <?php $__env->startSection('content'); ?>

 <body class="fixed-nav sticky-footer" id="page-top">
  <div class="content-wrapper">
      <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
              </li>
              <li class="breadcrumb-item Available to Order">Menu Management</li>
          </ol>
      <!-- Icon Cards-->
      <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card dashboard text-white bg-primary o-hidden h-100">
                  <div class="card-body">
                      <div class="card-body-icon">
                          <i class="fa fa-fw fa-list"></i>
                      </div>
                      <div class="mr-5">
                          <h5><?php echo e($all_item); ?> Menu Items</h5>
                      </div>
                  </div>
                  <!-- <a class="card-footer text-white clearfix small z-1" href="new-orders.html">
                              <span class="float-left">View Details</span>
                              <span class="float-right">
                                  <i class="fa fa-angle-right"></i>
                              </span>
                          </a> -->
              </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card dashboard text-white bg-success o-hidden h-100">
                  <div class="card-body">
                      <div class="card-body-icon">
                          <i class="fa fa-fw fa-shopping-cart"></i>
                      </div>
                      <div class="mr-5">
                          <h5><?php echo e($availability); ?> Available to Order</h5>
                          
                      </div>
                  </div>
                  <!-- <a class="card-footer text-white clearfix small z-1" href="processed-orders.html">
                              <span class="float-left">View Details</span>
                              <span class="float-right">
                                  <i class="fa fa-angle-right"></i>
                              </span>
                          </a> -->
              </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card dashboard text-white bg-warning o-hidden h-100">
                  <div class="card-body">
                      <div class="card-body-icon">
                          <i class="fa fa-fw fa-refresh"></i>
                      </div>
                      <div class="mr-5">
                          <h5><?php echo e($total_category); ?> Categories</h5>
                      </div>
                  </div>
                  <!-- <a class="card-footer text-white clearfix small z-1" href="pending-orders.html">
                              <span class="float-left">View Details</span>
                              <span class="float-right">
                                  <i class="fa fa-angle-right"></i>
                              </span>
                          </a> -->
              </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card dashboard text-white bg-danger o-hidden h-100">
                  <div class="card-body">
                      <div class="card-body-icon">
                          <i class="fa fa-fw fa-close"></i>
                      </div>
                      <div class="mr-5">
                          <h5><?php echo e($out_of_stock); ?> Out of Stock!</h5>
                      </div>
                  </div>
                  <!-- <a class="card-footer text-white clearfix small z-1" href="cancelled-orders.html">
                              <span class="float-left">View Details</span>
                              <span class="float-right">
                                  <i class="fa fa-angle-right"></i>
                              </span>
                          </a> -->
              </div>
          </div>
      </div>

      <div class="box_general padding_bottom">
            <div class="header_box version_2">
                <h2><i class="fa fa-file"></i>Add Menu Item</h2>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <p><a href="<?php echo e(route('add_menu_item')); ?>" class="btn_1 medium">Add Menu Item</a> </p>
                </div>
            </div>
        </div>
      <!-- /cards -->
          <!--  DataTables Card-->
          <div class="card mb-3">
              <div class="card-header">
                  <i class="fa fa-table"></i> Menu List Table</div>
              <div class="card-body">
                  <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                              <tr>
                                  <th>ID</th>
                                  <th>Name</th>
                                  <th>Category</th>
                                  <th>Price</th>
                                  <th>Availability</th>
                                  <th>Action</th>
                              </tr>
                          </thead>
                         
                          <tbody>
                              <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($data->id); ?></td>
                                  <td><?php echo e($data->name); ?></td>
                                  <td><?php echo e($data->category); ?></td>
                                  <td><?php echo e($data->price); ?></td>
                                  <td>
                                      <?php if($data->availability == 0): ?>
                                      <i class="cancel">Out of Stock</i>
                                      <?php endif; ?>
                                      <?php if($data->availability == 1): ?>
                                      <i class="approved">Available to Order</i>
                                      <?php endif; ?>
                                      
                                    </td>
                                  <td><a href="<?php echo e(route('edit_menu',[$data->id])); ?>"><strong>Edit</strong></a> | <a href="<?php echo e(route('delete_menu',[$data->id])); ?>"><strong>Delete</strong></a></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            
                          </tbody>
                      </table>
                  </div>
              </div>
              <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div> -->
          </div>
          <!-- /tables-->
      </div>
      <!-- /container-fluid-->
  </div>
  <!-- /container-wrapper-->
 
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                  </button>
              </div>
              <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
              <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                  <a class="btn btn-primary" href="#0">Logout</a>
              </div>
          </div>
      </div>
  </div>
  

</body>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH T:\xampp\htdocs\restaurant\resources\views/backend/layout/menu_management.blade.php ENDPATH**/ ?>