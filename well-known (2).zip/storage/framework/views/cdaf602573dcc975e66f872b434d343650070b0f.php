<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\foodmystro\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>