
 
<?php $__env->startSection('content'); ?>
<body class="fixed-nav sticky-footer" id="page-top">
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="menu-items.html">Menu Items</a>
                </li>
                <li class="breadcrumb-item active">Add Menu Item</li>
            </ol>
            <!-- /box_general-->
            <div class="box_general padding_bottom">
                <div class="header_box version_2">
                    <h2><i class="fa fa-list"></i>Add Menu item</h2>
                </div>
                <div class="wrapper_indent">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Choose Category</label>
                                <div class="styled-select">
                                    <select>
                                        <option>Appetizers</option>
                                        <option>Starters</option>
                                        <option>Main Courses</option>
                                        <option>Desserts</option>
                                        <option>Drinks</option>
                                        <option>Special Offers</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Availability</label>
                                <div class="styled-select">
                                    <select>
                                        <option>Available to Order</option>
                                        <option>Out of Stock</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Preparation Time</label>
                                <div class="styled-select">
                                    <select>
                                        <option>15 Minutes</option>
                                        <option>20 Minutes</option>
                                        <option>25 Minutes</option>
                                        <option>30 Minutes</option>
                                        <option>35 Minutes</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group radio_c_group no_label">
                                <label>Available For:</label>
                                <label class="container_radio">Delivery
                                    <input type="checkbox" value="checkbox" name="delivery" checked="checked">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="container_radio">Collection
                                    <input type="checkbox" value="checkbox" name="collection" checked="checked">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="container_radio">Table Service
                                    <input type="checkbox" value="checkbox" name="table-service" checked="checked">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <!-- /row-->
                    <div class="menu-item-section clearfix">
                        <h4>Menu item #1</h4>
                        <div>
                            <a href="#0"><i class="fa fa-plus-circle"></i></a>
                            <a href="#0"><i class="fa fa-minus-circle"></i></a>
                        </div>
                    </div>
                    <div class="strip_menu_items">
                        <div class="row">
                            <div class="col-xl-3">
                                <form action=/file-upload" class="dropzone"></form>
                            </div>
                            <div class="col-xl-9">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" name="menu_item_title" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Price</label>
                                            <input type="text" name="menu_item_title_price" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <div class="editor"></div>
                                </div>
                                <div class="form-group">
                                    <label>Item options</label>
                                    <div class="item_opt_wrapper">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="+ $3.50">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-8">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="Ex. Medium">
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group radio_c_group">
                                                    <label class="container_radio">Checkbox
                                                        <input type="radio" value="checkbox" name="option_item_settings_1" checked="checked">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                    <label class="container_radio">Radio
                                                        <input type="radio" value="checkbox" name="option_item_settings_1">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /row-->
                                    </div>
                                    <!-- /item_opt_wrapper-->
                                    <div class="item_opt_wrapper" style="background-color: #fff;">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="+ $5.50">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-8">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="Ex. Large">
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group radio_c_group">
                                                    <label class="container_radio">Checkbox
                                                        <input type="radio" value="checkbox" name="option_item_settings_2" checked="checked">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                    <label class="container_radio">Radio
                                                        <input type="radio" value="checkbox" name="option_item_settings_2">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /row-->
                                    </div>
                                    <!-- /item_opt_wrapper-->
                                </div><!-- End form-group -->
                                <div class="form-group">
                                    <label>Item ingredients</label>
                                    <div class="item_opt_wrapper">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="+ $2.50">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-8">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="Ex. Extra tomato">
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group radio_c_group">
                                                    <label class="container_radio">Checkbox
                                                        <input type="radio" value="checkbox" name="option_item_settings_3" checked="checked">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                    <label class="container_radio">Radio
                                                        <input type="radio" value="checkbox" name="option_item_settings_3">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /row-->
                                    </div>
                                    <!-- /item_opt_wrapper-->
                                    <div class="item_opt_wrapper" style="background-color: #fff;">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="+ $6.50">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-8">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="Ex. Extra pepper">
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group radio_c_group">
                                                    <label class="container_radio">Checkbox
                                                        <input type="radio" value="checkbox" name="option_item_settings_4" checked="checked">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                    <label class="container_radio">Radio
                                                        <input type="radio" value="checkbox" name="option_item_settings_4">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /row-->
                                    </div><!-- End form-group -->
                                </div>
                            </div><!-- End row -->
                        </div><!-- End strip_menu_items -->
                    </div>
                    <!-- /box_general-->
                </div>
                <!-- /.container-fluid-->
            </div>
            <!-- /.container-wrapper-->
            <p>
                <a href="#0" class="btn_1 medium">Save Item</a> 
                <a href="#0" class="btn_1 medium gray">Add another item</a>
            </p>
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fa fa-angle-up"></i>
            </a>
            
            <!-- Logout Modal-->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <a class="btn btn-primary" href="#0">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
           
</body>

<script>
            $('.editor').summernote({
                fontSizes: ['10', '14'],
                toolbar: [
                    // [groupName, [list of button]]
                    ['style', ['bold', 'italic', 'underline', 'clear']],
                    ['font', ['strikethrough']],
                    ['fontsize', ['fontsize']],
                    ['para', ['ul', 'ol', 'paragraph']]
                ],
                placeholder: 'Write here ....',
                tabsize: 2,
                height: 200
            });
            </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodmystro\resources\views/backend/layout/add_menu_item.blade.php ENDPATH**/ ?>